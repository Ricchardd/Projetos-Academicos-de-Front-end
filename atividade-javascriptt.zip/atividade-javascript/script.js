// 1. Busque os elementos do HTML pelo id. O defer garante que já existam.
const campoNome = document.querySelector('#nome');      // A) campo novo
const campo1 = document.querySelector('#nota1');
const campo2 = document.querySelector('#nota2');
const resultado = document.querySelector('#resultado');
const contadorTexto = document.querySelector('#contador'); // D) elemento novo
const botaoCalcular = document.querySelector('#calcular');
const botaoLimpar = document.querySelector('#limpar');

// D) Fica FORA das funções: assim o valor continua guardado entre um clique e outro.
// Se estivesse dentro de calcularMedia, voltaria a 0 a cada clique.
let calculosValidos = 0;

// Atualiza na tela o texto do contador.
function atualizarContador() {
  contadorTexto.textContent = `Cálculos válidos: ${calculosValidos}`;
}

// 2. Declare uma função: ela só roda quando for chamada.
function calcularMedia() {
  resultado.classList.remove('sucesso', 'atencao', 'erro');

  // B) trim() tira os espaços das pontas: "   " vira "" e é rejeitado.
  const nome = campoNome.value.trim();
  if (nome === '') {
    resultado.textContent = 'Informe o nome do estudante.';
    resultado.classList.add('erro');
    return; // Encerra aqui: não conta como cálculo válido.
  }

  // value é texto. Confira o vazio ANTES de converter: Number('') é 0.
  if (campo1.value.trim() === '' || campo2.value.trim() === '') {
    resultado.textContent = 'Preencha as duas notas.';
    resultado.classList.add('erro');
    return; // Encerra a função; não calcula com entrada incompleta.
  }

  const nota1 = Number(campo1.value);
  const nota2 = Number(campo2.value);

  // min/max no HTML orientam a entrada; nossa lógica também valida.
  if (!Number.isFinite(nota1) || !Number.isFinite(nota2) ||
      nota1 < 0 || nota1 > 10 || nota2 < 0 || nota2 > 10) {
    resultado.textContent = 'Use apenas notas de 0 a 10.';
    resultado.classList.add('erro');
    return;
  }

  const media = (nota1 + nota2) / 2;
  let situacao = 'Precisa revisar'; // let permite reatribuir o valor.
  let classe = 'atencao';
  if (media >= 6) {
    situacao = 'Meta atingida';
    classe = 'sucesso';
  }

  // D) Só chegamos aqui se nome e notas passaram em TODAS as validações.
  calculosValidos++;
  atualizarContador();

  // C) textContent mostra nome e média como TEXTO (não interpreta HTML).
  // toFixed(1) formata a exibição. A decisão usa a média sem arredondar.
  resultado.textContent = `${nome} — Média: ${media.toFixed(1)} — ${situacao}.`;
  resultado.classList.add(classe);
}

function limparCampos() {
  campoNome.value = '';  // D) apaga o nome
  campo1.value = '';
  campo2.value = '';
  calculosValidos = 0;   // D) zera a contagem
  atualizarContador();
  resultado.textContent = 'Aguardando os dados.';
  resultado.classList.remove('sucesso', 'atencao', 'erro');
  campoNome.focus();     // devolve o cursor ao primeiro campo
}

// 3. Conecte os eventos às funções (sem parênteses: não executar agora).
botaoCalcular.addEventListener('click', calcularMedia);
botaoLimpar.addEventListener('click', limparCampos);
