ATIVIDADE INDIVIDUAL - INTRODUÇÃO AO JAVASCRIPT (Front-end)
Prof. Carlos Allexandre | Aula de 30/10/2026

Nome: Carlos Richard Neres dos santos
RGM: 49522922
UNICSUL

Arquivos entregues: index.html, styles.css, script.js e este README.txt.
Para abrir: extrair o ZIP e dar duplo clique em index.html (não precisa de servidor).


==========================================================
1. O QUE FOI FEITO (itens A a E)
==========================================================

A) Campo de nome
   index.html: criei <label for="nome"> e <input id="nome" type="text">.
   script.js: selecionei o campo com document.querySelector('#nome') e guardei na constante campoNome.

B) Validação do nome
   script.js, função calcularMedia: const nome = campoNome.value.trim();
   O trim() tira os espaços das pontas. Se o resultado for '' (nome vazio ou só espaços), mostra "Informe o nome do estudante." com a classe erro e encerra com return.

C) Resultado com nome e média
   Quando tudo é válido, o resultado mostra, por exemplo: "Ana Souza — Média: 7.0 — Meta atingida."
   Foi feito com textContent e template string (crases e ${}).

D) Contador de cálculos válidos
   script.js: let calculosValidos = 0; declarada FORA das funções, para o valor não voltar a 0 a cada clique.
   Ela aumenta (calculosValidos++) somente depois de passar por todas as validações (nome, notas preenchidas e notas de 0 a 10).
   A contagem aparece no elemento novo <p id="contador"> ("Cálculos válidos: N").
   O botão Limpar apaga o nome e as notas, zera calculosValidos, atualiza o contador, volta a mensagem inicial e devolve o foco ao campo nome.

E) Personalização (styles.css) - o texto e a cor do resultado foram mantidos
   - Título: o <h1> virou "Cartão de acompanhamento" e o <title> da página também mudou.
   - Regra 1 (body): fundo mudou para verde-água suave (#e3efea).
   - Regra 2 (.etiqueta): texto em maiúsculas, espaço entre letras e cor mais escura (#1b6b52), com bom contraste sobre o branco.
   - As classes sucesso, atencao e erro do resultado não foram alteradas, então o texto continua legível. O foco do teclado (:focus-visible) foi mantido, e todos os campos têm label.


==========================================================
2. TESTES (item F)
==========================================================
Os testes foram executados no navegador. A coluna "Resultado obtido" é o que apareceu na tela.

| Caso                         | Entrada                          | Resultado obtido                                  | Contador |
|------------------------------|----------------------------------|---------------------------------------------------|----------|
| Média acima de 6             | Ana Souza, 8 e 6                 | Ana Souza — Média: 7.0 — Meta atingida.           | 1 |
| Média abaixo de 6            | Bruno Lima, 4 e 5                | Bruno Lima — Média: 4.5 — Precisa revisar.        | 2 |
| Média exatamente 6           | Carla Dias, 6 e 6                | Carla Dias — Média: 6.0 — Meta atingida.          | 3 |
| Média 6 com notas diferentes | Davi Reis, 5 e 7                 | Davi Reis — Média: 6.0 — Meta atingida.           | 4 |
| Entrada vazia (nota)         | Eva Prado, nota 1 vazia e 7      | Preencha as duas notas. (erro)                    | continua 4 |
| Nota -1                      | Eva Prado, -1 e 7                | Use apenas notas de 0 a 10. (erro)                | continua 4 |
| Nota 11                      | Eva Prado, 11 e 7                | Use apenas notas de 0 a 10. (erro)                | continua 4 |
| Nome só com espaços          | "   ", 7 e 7                     | Informe o nome do estudante. (erro)               | continua 4 |
| Nome vazio                   | (vazio), 7 e 7                   | Informe o nome do estudante. (erro)               | continua 4 |
| Botão Limpar                 | clicar em Limpar                 | Campos vazios, "Aguardando os dados.", sem cor, cursor no nome | 0 |
| Depois do Limpar             | Ana Souza, 10 e 10               | Ana Souza — Média: 10.0 — Meta atingida.          | 1 (recomeçou) |
| Limite inferior              | Ana Souza, 0 e 0                 | Ana Souza — Média: 0.0 — Precisa revisar.         | 2 |
| Texto no nome (textContent)  | <b>Ana</b>, 7 e 7                | O nome aparece como texto, sem virar negrito      | 3 |

Conclusões dos testes:
- Média 6 exata atinge a meta (a condição é media >= 6).
- Quando há erro (nome, nota vazia ou fora da faixa), o contador NÃO aumenta.
- O Limpar zera a contagem, e ela recomeça do 1.
- O console do navegador não mostrou erros.


==========================================================
3. EXPLICAÇÕES (item G)
==========================================================

const e let
- const guarda um valor que não vai ser trocado. Usei para os elementos da página (campoNome, campo1, resultado...) e para nome, nota1, nota2 e media.
- let guarda um valor que pode mudar depois. Usei em calculosValidos (aumenta a cada cálculo válido e volta a 0 no Limpar) e em situacao e classe (começam como "Precisa revisar" e podem virar "Meta atingida").

Number
- O que digitamos em um campo chega ao JavaScript como TEXTO. Se somarmos textos, "8" + "6" vira "86" e não 14.
- Number("8") converte o texto em número, e só assim a conta (nota1 + nota2) / 2 funciona.
- Cuidado: Number('') dá 0. Por isso confiro se o campo está vazio ANTES de converter. E Number.isFinite() confere se o resultado é um número de verdade (texto inválido vira NaN).

defer
- O <script> está no <head>, que é lido antes do <body>. Sem o defer, o JavaScript rodaria antes de os campos existirem, e o querySelector devolveria null.
- Com defer, o navegador baixa o script, mas só o executa depois de ler todo o HTML. Assim os elementos já existem quando o código os procura.

Sequência: evento -> leitura -> validação -> cálculo -> tela
1. Evento: o clique em "Calcular média" dispara a função calcularMedia (ligada com addEventListener, sem parênteses, para só executar no clique).
2. Leitura: pego o que foi digitado com .value (e uso trim() no nome).
3. Validação: confiro nome vazio, notas vazias e notas fora de 0 a 10. Se algo falhar, mostro o erro e dou return, sem calcular.
4. Cálculo: converto com Number, calculo a média, decido a situação (media >= 6) e só então aumento calculosValidos.
5. Tela: escrevo o resultado com textContent, coloco a classe de cor com classList.add e atualizo o contador.

textContent
- Escreve o conteúdo como texto puro. Se alguém digitar <b>Ana</b> no nome, aparece exatamente assim na tela, sem virar tag HTML. É mais seguro e mais simples.

Observação
- A média 6 é uma regra didática da atividade, não o regulamento da instituição. Todos os nomes usados nos testes são fictícios.
